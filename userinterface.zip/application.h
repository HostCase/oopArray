#ifndef APPLICATION_H
#define APPLICATION_H
#include <iostream>
class Application
{
public:
    Application();
    int exec();
private:
    int menuBar();
};

#endif // APPLICATION_H
