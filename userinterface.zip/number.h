#ifndef NUMBER_H
#define NUMBER_H
#include "complex.h"
//typedef double    number;
typedef Complex number;
#endif // NUMBER_H
